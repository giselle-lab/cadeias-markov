import java.io.IOException;
import java.io.FileWriter;

import java.util.ArrayList;

public class Set {
    ArrayList<Game> games = new ArrayList<>();
    Jogador vencedor;
    Jogador ja, jb;
    int gamesA;
    int gamesB;
    int totalDEGames;//numero de games jogados
    int totalDEPontos;//total de pontos por set

    public Set(Jogador ja, Jogador jb) {
        this.ja = ja;
        this.jb = jb;
        this.gamesA = 0;
        this.gamesB = 0;
        this.totalDEGames = 0;
        this.totalDEPontos = 0;
    }

    public int getGamesA() {
        return this.gamesA;
    }

    public int getGamesB() {
        return this.gamesB;
    }

    public int getTotalDEGames(){
        return this.totalDEGames;
    }

    //public void setTotalDEGames(int a){
    //    this.totalDEGames = a;
    //}

    public void setGames(int a, int b, boolean x) {
        if (!x) {
            this.gamesA = a;
            this.gamesB = b;
        } else {
            this.gamesA = 0;
            this.gamesB = 0;
        }
    }

    public void simula(FileWriter arq, FileWriter arqGerais) throws IOException {
        try {
            int totalGames = 0;
            //int totalDEPontos = 0;
            int totalTieBreaks = 0;
            while (true) {
                this.totalDEGames++;
                Game game = new Game(this.ja, this.jb);
                games.add(game);
                game.simula(arq);

                this.vencedor = game.getVencedor();
                if (this.vencedor == this.ja) {
                    this.gamesA++;
                    totalGames++;
                    arq.write("Jogador A ganhou " + gamesA + " game(s)\n");
                } else {
                    this.gamesB++;
                    totalGames++;
                    arq.write("Jogador B ganhou " + gamesB + " game(s)\n");
                }

                if (this.gamesA >= this.gamesB + 2 && this.gamesA >= 6) {
                    // A venceu
                    this.vencedor = this.ja;
                    ja.alteraSetsJogador();
                    arq.write("Jogador A Venceu Set!"+"\n");
                    arq.write("Placar de Games: " + this.gamesA + " x " + this.gamesB +"\n");
                    break;
                } else if (this.gamesB >= this.gamesA + 2 && this.gamesB >= 6) {
                    // B venceu
                    this.vencedor = this.jb;
                    jb.alteraSetsJogador();
                    arq.write("Jogador B Venceu Set!\n");
                    arq.write("Placar de Games: " + this.gamesA + " x " + this.gamesB+"\n");
                    break;
                }
                // tie break: Ganha quem ganhar o game 7
                else if (this.gamesA == 6 && this.gamesB == 6) {
                    game.resetPontos();
                    game.simulaTieBreak(arq);
                    this.vencedor = game.getVencedor();
                    if (this.vencedor == this.ja) {
                        this.gamesA++;
                        totalTieBreaks++;
                        arq.write("\n");
                        arq.write("Jogador A Venceu o Tie Break!\n");
                        arq.write("Jogador A ganhou: " + gamesA + " game(s)\n");
                        arq.write("\n");
                        arq.write("Jogador A Venceu Set!\n");
                        arq.write("\n");
                        break;
                    } else {
                        this.gamesB++;
                        totalTieBreaks++;
                        arq.write("\n");
                        arq.write("Jogador B Venceu o Tie Break!\n");
                        arq.write("Jogador B ganhou: " + gamesB + " game(s)\n");
                        arq.write("\n");
                        arq.write("Jogador B Venceu Set!\n");
                        arq.write("\n");
                        break;
                    }
                }
                this.totalDEPontos += game.totalPontos;
                arq.write("\n");
            }

            /*arqGerais.write("\n");
            this.ja.imprimeGames(arqGerais, totalGames);
            this.jb.imprimeGames(arqGerais, totalGames);
            arqGerais.write("\n");
            if(totalTieBreaks != 0){
                this.ja.imprimeTieBreak(arqGerais, totalTieBreaks);
                this.jb.imprimeTieBreak(arqGerais, totalTieBreaks);
                arqGerais.write("\n");
                this.ja.imprimeTotalGamesGanhos(arqGerais, totalGames+totalTieBreaks);
                this.jb.imprimeTotalGamesGanhos(arqGerais, totalGames+totalTieBreaks);
                arqGerais.write("\n");
            }
            this.ja.resetetGames();
            this.jb.resetetGames();
            this.ja.resetetTieBreaks();
            this.jb.resetetTieBreaks();
            arqGerais.write("\n");
            totalGames = 0;
            totalTieBreaks = 0;*/
            this.totalDEGames = totalGames + totalTieBreaks; ;
        } catch (Exception e) {
            throw new IOException();
        }
    }

    public Jogador getVencedor() {
        return this.vencedor;
    }

}