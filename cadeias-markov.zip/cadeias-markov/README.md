# cadeias-markov

descrição

Para compilar: $make

Para executar: $make run

Para limpar: $make clean
