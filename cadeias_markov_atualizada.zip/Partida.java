import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;

public class Partida {
    ArrayList<Set> sets = new ArrayList<>();
    Jogador ja, jb;
    int setsJa, setsJb;
    Jogador vencedor;
    int totalSets;//total de sets na partida
    int totalDEPontos;//total de pontos na partida inteira

    public Partida(Jogador ja, Jogador jb) {
        this.ja = ja;
        this.jb = jb;
        this.setsJa = 0;
        this.setsJb = 0;
        this.totalSets = 0;
        this.totalDEPontos = 0;
    }

    public Jogador getJogadorA(){
         return this.ja;
     }

    public Jogador getJogadorB(){
         return this.jb;
     }

    public void simula(FileWriter arq, FileWriter arqGerais) throws IOException {
        try {
            int totalGames = 0;
            int numSet = 1;
            boolean teve3Sets = false;
            while (true) {
                Set set = new Set(this.ja, this.jb);
                arq.write("Set " + numSet + ":");
                arq.write("\n");
                set.simula(arq,arqGerais);
                this.vencedor = set.getVencedor();
                if (this.vencedor == this.ja) {
                    this.setsJa++;
                    numSet++;
                    totalGames += set.getTotalDEGames();
                    arq.write("Placar de Sets: "  + this.setsJa + " x " + this.setsJb+"\n");
                    arq.write("\n");
                } else {
                    this.setsJb++;
                    numSet++;
                    totalGames += set.getTotalDEGames();
                    arq.write("Placar de Sets: " +  this.setsJa + " x " + this.setsJb+"\n");
                    arq.write("\n");
                }

                if (this.setsJa >= this.setsJb + 2) {
                    // A venceu
                    this.totalDEPontos += set.totalDEPontos;
                    this.vencedor = this.ja;
                    ja.alteraPartidasJogador();
                    arq.write("Jogador A Venceu a Partida!\n");
                    arq.write("Placar de Sets Final: " + this.setsJa + " x " + this.setsJb);
                    arq.write("\n");
                    break;
                } else if (this.setsJb >= this.setsJa + 2) {
                    // B venceu
                    this.totalDEPontos += set.totalDEPontos;
                    this.vencedor = this.jb;
                    jb.alteraPartidasJogador();
                    arq.write("Jogador B Venceu a Partida!\n");
                    arq.write("Placar de Sets Final: " + this.setsJa + " x " + this.setsJb);
                    arq.write("\n");
                    break;
                }
                //se empatou os sets
                if (this.setsJa == 1 && this.setsJb == 1) {
                    arq.write("Set " + 3 + ":");
                    arq.write("\n");
                    teve3Sets = true;
                    set.setGames(0, 0, true);
                    set.totalDEPontos = 0;

                    set.simula(arq,arqGerais);
                    
                    this.totalDEPontos += set.getTotalDEPontos();
                    this.vencedor = set.getVencedor();
                    totalGames += set.getTotalDEGames();
                    if (this.vencedor == this.ja) {
                        this.setsJa++;
                        this.totalDEPontos += set.totalDEPontos;
                        ja.alteraPartidasJogador();
                        arq.write("\n");
                        arq.write("Jogador A Venceu a Partida!\n");
                        arq.write("Placar Sets: " + this.setsJa + " x " + this.setsJb);
                        arq.write("\n");
                        break;
                    } else {
                        this.setsJb++;
                        this.totalDEPontos += set.totalDEPontos;
                        jb.alteraPartidasJogador();
                        arq.write("\n");
                        arq.write("Jogador B Venceu a Partida!\n");
                        arq.write("Placar Sets: " + this.setsJa + " x " + this.setsJb);
                        arq.write("\n");
                        break;
                    }
                }
                this.totalDEPontos += set.totalDEPontos;
            }//fim do while
            if(teve3Sets){
                this.totalSets = 3;
            } else {
                this.totalSets = 2;
            }
            arqGerais.write("Ocorreram um total de " + this.totalSets + " sets\n");
            arqGerais.write("Ocorreram um total de " + totalGames + " games\n");
            arqGerais.write("Ocorreram um total de " + this.totalDEPontos + " pontos\n");
            arqGerais.write("\n");
            arq.write("\n");
        } catch (Exception e) {
            throw new IOException();
        }
    }

    public String getVencedor() {
        return this.vencedor.getNome();
    }

    public int getTotalSets(){
        return this.totalSets;
    }

    public void setSets(int a, int b) {
        this.setsJa = a;
        this.setsJb = b;
    }


}